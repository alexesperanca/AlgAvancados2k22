var searchData=
[
  ['sequence_0',['Sequence',['../class_algorithm_package_1_1_sequence_1_1_sequence.html',1,'AlgorithmPackage::Sequence']]],
  ['suffixtree_1',['SuffixTree',['../class_algorithm_package_1_1trie_1_1_suffix_tree.html',1,'AlgorithmPackage::trie']]]
];
