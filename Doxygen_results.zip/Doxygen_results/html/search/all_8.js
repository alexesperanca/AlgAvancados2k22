var searchData=
[
  ['heuristicconsensus_0',['heuristicConsensus',['../class_algorithm_package_1_1_motif_finding_1_1_motif_finding.html#a3b9c02750c12d691577b83eb81faa242',1,'AlgorithmPackage::MotifFinding::MotifFinding']]],
  ['heuristicstochastic_1',['heuristicStochastic',['../class_algorithm_package_1_1_motif_finding_1_1_motif_finding.html#a0883ff530a25845aaf053f426ce508dc',1,'AlgorithmPackage::MotifFinding::MotifFinding']]]
];
