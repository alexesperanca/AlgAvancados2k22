var searchData=
[
  ['nextsol_0',['nextSol',['../class_algorithm_package_1_1_motif_finding_1_1_motif_finding.html#a7c71e1083c7ae3de4ecbb8c343c787b5',1,'AlgorithmPackage::MotifFinding::MotifFinding']]],
  ['nextstate_1',['nextState',['../class_algorithm_package_1_1_automata_1_1_automata.html#a507317404b6aa71b354a3178b5198411',1,'AlgorithmPackage::Automata::Automata']]],
  ['nextvertex_2',['nextVertex',['../class_algorithm_package_1_1_motif_finding_1_1_motif_finding.html#aac5e7794dbb53ea2f166499b2ff8b31e',1,'AlgorithmPackage::MotifFinding::MotifFinding']]]
];
