var searchData=
[
  ['trie_0',['Trie',['../class_algorithm_package_1_1trie_1_1_trie.html',1,'AlgorithmPackage::trie']]]
];
